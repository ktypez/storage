./minerd -a scrypt -o stratum+tcp://hash-to-coins.com:3333 -u ktypez.1 -p x
